
package progpoepart1;


public class Login                                                              //Here we are creating some strings and constants that we can use , the names are direct refernces to the needed conditions according to the POE.
{
    private String name = "";                                                   //these 4 private strings are going to be used for the login credentials and for registering a new user.
    private String surname = "";
    private String username = "";
    private String password = "";
    
    private final int MAX_USERNAME = 5;                                         //these strings and intetures are under "final" so that value cant change , finals = constants.  
    private final int MIN_PASSWORD = 8;
    private final String UNDERSCORE = "_";
    private final String SPECIAL = "!@#$%^&*()-+{}[]|\\;:?.,<>";
    
    
    //(------------------------------------------------------------------------)This is a basic System.out.println function that makes the code needed for printing a message out alot shorter by just saying "print".
    
    
    public static void print(String sentence) 
    { 
    System.out.println(sentence); 
    } 
    
    
    
    //(------------------------------------------------------------------------)We start with the username.
    
    
    
    public boolean checkUserName(String scanFor)                                //POE requires use of boolean here , this makes it alot simpler for us. 
    {
        boolean valid = false;
        
        if (scanFor.length() <= MAX_USERNAME )                                  //length check for less then or equal to username length peramiters which is 5 characters long. 
        {
            if (scanFor.contains(UNDERSCORE))                                   //the contain method use here optimal as it scans if the username "contains" what is set in the perameters which in this case is an "underscore". 
                {
                    valid = true;
                }
                if (valid)
                    {
                        print("Username successfully captured");
                    }
        }     
    return valid;
    }                                
    
    
    
    //(------------------------------------------------------------------------)

    
    
    public boolean checkSPECIAL(String scanFor)                                 
    {
        boolean valid = false;
        
        for(int i = 0; i < SPECIAL.length(); i++)                               //here is an counter to count the length of the special charcters ,this is to make sure ther is atleast 1 special character. 
        {  
            String str;                                                         
            str = Character.toString(SPECIAL.charAt(i));
            if (scanFor.contains (str))
            {
              valid = true;                                                     //valid is set to true if password contains atleast 1 special character.
              break;
            }
        }
        return valid;                                                           //valid is returned.
    }
    
    
    
    //(------------------------------------------------------------------------)
    
    
    
    public boolean checkDigit(String scanFor)                                   //This section checks the password for if there is atleast 1 digit. 
    {
        boolean valid = false;                                                  //boolean is set to false and will only change if valid is returned.
        
        
        for(int i = 0; i < scanFor.length(); i ++)                              //this scans the text of the "password" and goes through every character to look for a digit, i++ means to continue from the one character to the rest on the search for a digit.
        {  
            if(Character.isDigit(scanFor.charAt(i)))                            //only in this line a digit is what the function i slooking for , declared the meaning of a digit by javas built in definition of a digit = "isDigit".
            {
                {
                    valid = true;
                    break;
                }
            }
        }
        return valid;                                                           //if all the above checks are complete and meets the requirements of atleast 1 digit, then the valid is returned as true.
    }
    
    
    
    //(------------------------------------------------------------------------)

    /**
     *
     * @param scanFor
     * @return
     */
    
    
    
    public boolean checkUpper(String scanFor)                                   //copy paste + modify from checkDigit , it is the exact same consept the only difference is the fact that this module uses "isUpper" which looks for an uppercase. 
    {                                                                           //the reason his part can be copy and pasted from the checkDigit section is because both use the internal stored libary of javas features like "isDigit" and "isUpper".
        boolean valid = false;
        
        for(int i = 0; i < scanFor.length(); i ++)                  
        {  
            if(Character.isUpperCase(scanFor.charAt(i)))
            {
                {
                    valid = true;
                    break;
                }
            }
        }
        return valid;
    }
    
    
    //(------------------------------------------------------------------------)
    
    /**
     *
     * @param PswCmpl
     * @return
     */
    public boolean checkPasswordComplexity(String PswCmpl)                      //runs through all modules and if all come back as valid = true ,  
    {                                                                           //a valid will be returned in passwordcomplexity to turn boolean to true.
        boolean valid = false;
        if    ((PswCmpl.length() >= MIN_PASSWORD)                               //This checks the length of the password to see if the minimum length is 8 charcters long.
           && (checkSPECIAL (PswCmpl))                                          //This checks if the password contains atleast 1 special character.
           && (checkUpper   (PswCmpl))                                          //checks if the passwor dcontains atleast 1 uppercase character.
           && (checkDigit   (PswCmpl)))                                         //This checks if the password has atleast 1 dgit using javas built in feature "isDigit" so that an additional string with each individual number doesnt have to be clarified as see by the "SPECIAL" string.
                {
                 valid = true;
                }
                if (valid)                                                      //if the boolean returns as valid a message will appear saying "Password successfully captured".
                    {
                        print("Password successfully captured");
                    }
        return valid;
    }
    
    
    
    //(------------------------------------------------------------------------)By rightclicking on all the above strings and refractoring it , you can generate getters and setters which will create variables that can be inserted with information that will be stored after a user is prompted to give information like example a username.
    
    
    
    /**
     * @return the name
     */
    public String getName() 
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) 
    {
        this.name = name;
    }

    /**
     * @return the surname
     */
    public String getSurname() 
    {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) 
    {
        this.surname = surname;
    }

    /**
     * @return the username
     */
    public String getUsername() 
    {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) 
    {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() 
    {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) 
    {
        this.password = password;
    }

    /**
     * @return the MAX_USERNAME
     */
    public int getMAX_USERNAME() 
    {
        return MAX_USERNAME;
    }

    /**
     * @return the MIN_PASSWORD
     */
    public int getMIN_PASSWORD() 
    {
        return MIN_PASSWORD;
    }

    /**
     * @return the UNDERSCORE
     */
    public String getUNDERSCORE() 
    {
        return UNDERSCORE;
    }

    /**
     * @return the SPECIAL
     */
    public String getSPECIAL() 
    {
        return SPECIAL;
    }
    
}                                                                               
 

//Tiaan Burger
//number : 0609970150
//ST10031718
//Prog Poe Part 1



package progpoepart1;
                                                                                //PLS NOTE THAT THIS PROGRAM WAS CODED USING APACHE NETBEANS IDE 13 , FEATURES LIKE TEXT BLOCKS MIGHT NOT WORK ON OTHER NETBEANS VERSIONS

/**
 *
 * @author Tiaan B. ST10031718
 */
public class ProgPoePart1                                                       //!!!!!!!!!!!!!!!!!!!!!
{
    public static void main(String[] args) 
    {
        Worker work = new Worker();                                             //here we are spawning a new worker that all the modules will be set and done in an sepparate class called "worker".
        work.mainThread();                                                      //here we are calling upon the mainthread inside the worker
        System.exit(0);
    } 
}

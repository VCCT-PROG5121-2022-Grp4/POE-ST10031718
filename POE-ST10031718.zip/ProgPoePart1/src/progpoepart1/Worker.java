                                                 
package progpoepart1;

import javax.swing.JOptionPane;                                                 //JOptionPane makes it easy to pop up a 
                                                                                //dialog box that prompts users for a value or informs them of something.                                                     
import java.util.Scanner;                                                       //importing the utility scanner for java because we will be asking multiple questions that will appear in the console and will be answered in the console aswell, this will be read bu the scanner.


    //(------------------------------------------------------------------------)


public class Worker                                                             //"i" is used for the counter !!!
{
    private static final int USERS_MAX = 5;
    final static int MAX_TASKS = 5;
    Login users[] = new Login[USERS_MAX];                                       //this is where we are creating a new call for the new class created "login".
    private int numUsers = 0;                                                   // this value of number of users is set to 0 at this time and will increase after a new user is registered.
    private int currentLoggedUser = 0;                                          //this value is asell set to 0 but will increase on the amount of users that are logged in currentlt , in this program it is capped to 1 user logged at a time , so this number will only increase to 1 and no more.
    Task task[] = new Task[MAX_TASKS];                                          //this is where we are creating a new call for the new class created "task".
    
    //(------------------------------------------------------------------------)
        
    public static void print(String sentence)                                   //shortens the system.out.println code needed to just print , makes it easier for me to use.
    { 
    System.out.println(sentence); 
    } 
   
    public void printMsg(String plainMsg)
    {
        JOptionPane.showMessageDialog(null,
                        plainMsg,
                        "Message",
                        JOptionPane.PLAIN_MESSAGE);
    }
         
    public void printError(String errorMsg)                                     //this will be a generic error message that will be called upon if the user runs into a validations error , like mis typing something or giving the wrong input , or not meeting certain password/username requirements
    {
       JOptionPane.showMessageDialog(null,
               errorMsg, "ERROR", JOptionPane.ERROR_MESSAGE);
    }
    
    
    //(------------------------------------------------------------------------)
    
    public void mainThread()                                                    //This is a switch method that will be continued with if each of the users input corresponds with one of the cases 
    {
      int selection = 0;                                                        //int selection is defaulted to 0 until other input is made //integer of selection is returned from printLoginMenu
      boolean quit = false;                                                     //presume that they don't want to quit
      boolean loggedIn;  
        do
        {
          selection = printLoginMenu();  
           switch (selection) 
            {
                case 1 -> //register a user
                   registerUser();
                case 2 -> //login user
                   {
                        loggedIn = loginUser();
                        if (!loggedIn)
                        {
                            printError("""
                                    Username or password incorrect
                                    please try again.
                                    """
                                      );
                        }
                        else
                        {
                            printMsg("Welcome " +
                                    users[currentLoggedUser].getName() +
                                     users[currentLoggedUser].getSurname() +
                                    ","+ "it is great to see you again.");
                                    printCanBanMenu();
                        }
                   }
                default -> //quit                                                //switch statements should always have a default clause 
                   quit = true;
           }
           print("\n Num of Reg-Users:" + numUsers);
       }while (!quit);                                                          //input does not equal atleast quit then loop 
     }    

//(----------------------------------------------------------------------------)
    
    
    public boolean checkEmptyNull(String toScan)                                
    {
        boolean valid = false;                                                  //boolean defaults to false and will return when its true , thus it will return if all stribgs are not empty nor null.
                                                                                //nested if statement is used to make it easier to see the steps that the program is taking to look through these string.
        if (toScan != null)                                                     //if the "toScan" string returned as not equal to null it will move on to next if statement.
            {                                                                   
                if (!toScan.isEmpty())                                          //if toScan string is not equal to null not empty then it will continue and return i valid.
                {
                    valid = true;
                }
            }
        //check to make sure strings are never empty nor null
        return valid;
    }
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//(----------------------------------------------------------------------------)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
    
    public void registerUser()
    {
      boolean valid  = false;
      //this boolean will be returned only if valid ,if !valid it will loop until the menu is quit upon or valid input has been given.
      //this is giving forsight that we will be doing a do while loop so that the it will only stop looping if valid is returned as valid.
      String userInput = "_";
      Scanner input = new Scanner(System.in);
      //the scanner will be called here because we are asking multiple questions and require input from the user , thus "system.in" for input.
      Login Guest = new Login();                                                //This is going to be the temperary login. 
      
      
      do
        {
            print("Enter new Username [<6 + _]:" );                             //prints new message to prompt for username.
            if (checkEmptyNull(userInput))                                      //checking username.
            {
                userInput = input.next();

                if ((checkEmptyNull(userInput))) 
                {
                    if (Guest.checkUserName(userInput))
                    {
                        valid = true;
                    }       
                           
                    if (!valid)                                                 //if the users inputted username is not valid a error message is outputted. 
                    {
                    printError(""" 
                                Username is not correctly formated,
                                please ensure that your username contains,
                                a underscore and is no more than 5 characters
                                in length."""                                   //Default POE error message.
                               );
                    }
                }
            }
        }while(!valid);
        Guest.setUsername(userInput);
         
       
    valid = false;
        do
        {
            print("Enter new Password [>8 + UPPPER + 0-9 + SPECIAL]:" ); 
            userInput = input.next();
            if (checkEmptyNull(userInput))                                      //if the users input is not empty nor null it will proceed.
            
            {
                if (Guest.checkPasswordComplexity(userInput))                   //this will output a valid that will return and set valid to valid = true only if all "checkPasswordComplexity" ' s requirements are met. 
                {
                    valid = true;
                }

                if (!valid)                                                     // if the above conditions are not met then it will not be valid and will prompt the default Poe error message.
                {                                                               //text block feature is used here """___"""
                    printError(""" 
                               Password is not correctly formatted, 
                               please ensure that the password contains at 
                               least 8 characters, a capital letter, 
                               a number and a special character
                               """);                                            //Default POE error message.
                }
            }
            
        }  while(!valid);   
        
        Guest.setPassword(userInput);                                           //set password , set name , set surname.
        print("Enter FirstName :");
        Guest.setName(input.next());
        print("Enter Surname :");
        Guest.setSurname(input.next());
        
        users[numUsers] = Guest;                                                //assign Guest to actual array, this will increase the number of users listed as registered on the system.
        numUsers++;                                                             //Number of registered users goes up by 1 , after new user is registered.
        
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //(------------------------------------------------------------------------)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    public void printCanBanMenu()
    {
        int selection = 0;
        boolean quit = false;
      
        
        do
        {
            selection = printCanBanTaskMenu();
            switch (selection)
            {
                case 1 -> addCanBanTasks();
                case 2 -> 
                {
                    printMsg("Task 3 , Coming Soon ");
                }
                default -> quit = true; 
            }
        }while(!quit);
    }
    
//------------------------------------------------------------------------------
    public int printCanBanTaskMenu()
    {
        int selection = 0;                                                      //variable has been intialised at = 0 //selection is tored in integer "selection" , will be returned to the switch.
        boolean valid = false;                                                  //boolean valid is feault to false and will be set to true after valid is returned.
        String userInput = "";                                                  //creates a strinhg for the users input.
        
        do
        {                                                                       //if user press "cancel" it returns a null.
            userInput = JOptionPane.showInputDialog(null,                       //text block feature is used here """___""".
                    """
                    \t UserSelectMenu
                    ﹌﹌﹌﹌﹌﹌﹌﹌﹌﹌﹌﹌                                         
                    \t1. Add Task                                          
                    \t2. Show Report
                    \t3. Quit""",
                    "CAN BAN APP",
                    JOptionPane.INFORMATION_MESSAGE);                           //no Parent window so we say null.
            
            if (checkEmptyNull(userInput))                                     
            {
                selection = Integer.parseInt(userInput);                        //parsing (evaluate and convert string into integer)(userInput --> selection).
                
                if ((selection > 0) && (selection < 4 ))                        //range check between 1 and 3, because the users input can only be 1, 2 , 3.
                {
                    valid = true;
                }
            }
            
             if (!valid)                                                        //if the users input is not between 1-3 then error message will be prompted.
                {
                    printError("Users input can only be between 1 and 3 ,"
                            + " please try again");
                }
        } 
        while(!valid);                                                          //if valid then return selection. 
        return selection;                                                       //returning integer.
    }
//------------------------------------------------------------------------------
    
public void addCanBanTasks()
{
    String userInput = "";
    int taskAmount = 0;

    userInput = JOptionPane.showInputDialog(null,
            "Please enter the number of tasks to add",
            "Add Tasks", JOptionPane.QUESTION_MESSAGE);
    
    if ((userInput == null) || (userInput.isEmpty()))
    {
        printError("Assuming quit - invalid value detected");
        return;
    }
    
    taskAmount = Integer.parseInt(userInput);
    print("\n\n~~~~~ CREATING " + taskAmount + " TASKS ~~~~~");
    
    for (int i = 0; i < taskAmount; i++)
    {
        addTask(i);
    }
    
    print("\n~~~~~  TASK WAS CAPTURED ~~~~~\n");
}


public void addTask(int i)
{
    Scanner input = new Scanner(System.in);
    Task user = new Task();
    
    String printTask;
    String taskName;
    String taskDescr;
    String devDetail;
    String taskID;
    int taskDuration;
    int taskStatus;
    int overall = Task.getIncrementTaskNumber(); 
    
    print("TASK " + (i + 1)); 
    print("------------------------------");
    print("Task Name: ");
    taskName = input.nextLine();
    boolean valid = false;
    
    do 
    {
        print("Task Description: ");
        taskDescr = input.nextLine();
        if (!user.checkTaskDescription(taskDescr))
        {
           printError("Please enter a task description of less than 50 characters"); 
        }
        else 
        {
            valid = true;
        }
    }while(!valid);
    print("Developer Details: ");
    devDetail = input.nextLine();
    print("Task Duration: ");
    taskDuration = input.nextInt();
    input.nextLine();
    
    //----------------------------------------------------------------------
    
    print("What is the status of your task ? ");
    print("1 - To Do # 2 - Doing # 3 - Done");
    valid = false;
    do 
    {
        print("Status choice: ");
        taskStatus = input.nextInt();
        input.nextLine();
        if ((taskStatus < 1) || (taskStatus > 3))
        {
            printError("Value can only be choice 1, 2 or 3");
        }
        else
        {
            taskStatus--; // subtract 1 to build an array index for STATUS
            valid = true;
        }
    } while(!valid);
    print("------------------------------");
    
    //----------------------------------------------------------------------
    
    taskID = user.createTaskID(taskName ,overall, devDetail);
    
    user.setTaskNumber();                   // set the task number)
    user.setTaskID(taskID);                 // set task ID 
    user.setTaskName(taskName);             // set the task name
    user.setTaskDescription(taskDescr);     // set task description
    user.setDeveloperDetails(devDetail);    // set developer details
    user.setTaskDuration(taskDuration);     // set task duration 
    user.setTaskStatus(taskStatus);         // set the task status
    
    printMsg(user.printTaskDetails());      // Display all task details
    
    task[overall] = user;   
}   
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//(---------------------------LOGIN--------------------------------------------)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    public int printLoginMenu()
    {
        int selection = 0;                                                      //variable has been intialised at = 0 //selection is tored in integer "selection" , will be returned to the switch.
        boolean valid = false;                                                  //boolean valid is feault to false and will be set to true after valid is returned.
        String userInput = "";                                                  //creates a strinhg for the users input.
        
        do
        {                                                                       //if user press "cancel" it returns a null.
            userInput = JOptionPane.showInputDialog(null,                       //text block feature is used here """___""".
                    """
                    \t UserSelectMenu
                    ﹌﹌﹌﹌﹌﹌﹌﹌﹌﹌﹌﹌                                         
                    \t1. Register User                                          
                    \t2. Login A User
                    \t3. Quit Menu""",
                    "CAN BAN APP",
                    JOptionPane.INFORMATION_MESSAGE);                           //no Parent window so we say null.
            
            if (checkEmptyNull(userInput))                                     
            {
                selection = Integer.parseInt(userInput);                        //parsing (evaluate and convert string into integer)(userInput --> selection).
                
                if ((selection > 0) && (selection < 4 ))                        //range check between 1 and 3, because the users input can only be 1, 2 , 3.
                {
                    valid = true;
                }
            }
            
             if (!valid)                                                        //if the users input is not between 1-3 then error message will be prompted.
                {
                    printError("Users input can only be between 1 and 3 ,"
                            + " please try again");
                }
        } 
        while(!valid);                                                          //if valid then return selection. 
        return selection;                                                       //returning integer.
    }
          
//(----------------------------------------------------------------------------)    
 
    
    public boolean loginUser()                                                            
    {
        
        boolean valid = false;                                                  
        Scanner input = new Scanner(System.in);
        String username, password;
        
        print("Please enter username : ");                                      //after entering username this move on to the next part --> password.
        username = input.next();
        print("Please enter Password : ");            
        password = input.next();
        
        for (int i = 0; i < numUsers; i++)                                      //this is where the getters and setters from the login class come into play. 
        {
            if (users[i].getUsername().equals(username))                        //if the username that was inputed above is equal to the username that was set in the login class that is then fetched here this will then move onto the code of the next part , the password <---
            {
                if (users[i].getPassword().equals(password))                    //if the password that was inputed above is equal to the password that was set in the login class that is then fetched here then this module will return a valid and the user will be premitted to login.
                {
                    valid = true;                                                   
                    currentLoggedUser = i;                                      //record logged in users 
                }                                                               //!! ONLY IF BOTH USERNAME AND PASSWORD IS CORRECT IT WILL LET THEM THROUGH , IF ATLEAST ONE IS WRONG IT WONT SAY WHICH (USERNAME NOR PASSWORD) THIS IS TO PREVENT BRUTE FORCING BY GUESSING.
            }
        }return valid;
    }
    
}
//(----------------------------------------------------------------------------)

package progpoepart1;

/**
 *
 * @author ST10031718
 */

public class Task 
{
    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~STRINGS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
    
private String taskName = "";
//number of task (will be updated)
private int taskNumber = 0;
//this will update the number of tasks 
private static int incrementTaskNumber = 0; 


private String taskDescription = ""; 
private final int MAX_DESCRIPTION_LENGTH = 50;


private String developerDetails = "";//Poe requires there to be asked the developers details


private int taskDuration = 0;
private static int totalTaskDuration = 0;


private String taskID = ""; 
//The task will be given a identity number that 
//consist out of the first 2 characters of the tasks name and
//a colon (:), the Task Number, a colon (:) 
//and the last three letters of the developer 


private String taskStatus = "";
private final String[] STATUS = {"To Do", "Doing", "Done"};


public String createTaskID(String taskName, int taskIncr, String developer)
{
    //substring is used here to only get a part of the strings contents , thus where the parameters are set 
    //paramiters set to 0-2 to capture the first 2 characters to be used in the task ID
    String temp = taskName.substring(0, 2); 
    temp = temp + ":" + taskIncr + ":";
    //Length of the developers name is read and only the last 3 characters are taken to be added to the ID
    temp = temp + developer.substring((developer.length() - 3));
   
    return temp.toUpperCase();
}

public boolean checkTaskDescription(String taskDescription)
{
    return(taskDescription.length() <= MAX_DESCRIPTION_LENGTH);
}      

public String printTaskDetails()
{  
        String returnString  
        = this.taskStatus
        + ", "
        + this.developerDetails + " "
        + this.taskNumber + " "
        + this.taskName + " " 
        + this.taskDescription + " " 
        + this.taskID + " "
        + this.taskDuration; 
        
         return returnString;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Duration~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public void setTaskDuration(int taskDuration)
{ 
    this.taskDuration = taskDuration;
     Task.totalTaskDuration = Task.totalTaskDuration + taskDuration;
}

public int returnTotalHours()
{
    return Task.totalTaskDuration;
}

//~~~~~~~~~~~~~~~~~~~~~~~~Status~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


public void setTaskStatus(int taskSelection)
{   
    this.taskStatus = STATUS[taskSelection];
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~TaskNumber~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

public void setTaskNumber()
{ 
    //tasknumber is being increased by the amount of selected task that the 
    //user wants to do 
    this.taskNumber = Task.incrementTaskNumber;
    Task.incrementTaskNumber++;
}





//~~~~~~~~~~~~~~~~~~~~~~~~~~Getters and Setters~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * @return the MAX_DESCRIPTION_LENGTH
     */
    public int getMAX_DESCRIPTION_LENGTH() 
    {
        return MAX_DESCRIPTION_LENGTH;
    }

    /**
     * @return the STATUS
     */
    public String[] getSTATUS() 
    {
        return STATUS;
    }

    /**
     * @return the incrementTaskNumber
     */
    public static int getIncrementTaskNumber() 
    {
        return incrementTaskNumber;
    }

    /**
     * @param aIncrementTaskNumber the incrementTaskNumber to set
     */
    public static void setIncrementTaskNumber(int aIncrementTaskNumber) 
    {
        incrementTaskNumber = aIncrementTaskNumber;
    }

    /**
     * @return the totalTaskDuration
     */
    public static int getTotalTaskDuration() 
    {
        return totalTaskDuration;
    }

    /**
     * @param aTotalTaskDuration the totalTaskDuration to set
     */
    public static void setTotalTaskDuration(int aTotalTaskDuration) 
    {
        totalTaskDuration = aTotalTaskDuration;
    }

    /**
     * @return the taskNumber
     */
    public int getTaskNumber() 
    {
        return taskNumber;
    }

    /**
     * @param taskNumber the taskNumber to set
     */
    public void setTaskNumber(int taskNumber) 
    {
        this.taskNumber = taskNumber;
    }

    /**
     * @return the taskName
     */
    public String getTaskName() 
    {
        return taskName;
    }

    /**
     * @param taskName the taskName to set
     */
    public void setTaskName(String taskName) 
    {
        this.taskName = taskName;
    }

    /**
     * @return the taskDescription
     */
    public String getTaskDescription() 
    {
        return taskDescription;
    }

    /**
     * @param taskDescription the taskDescription to set
     */
    public void setTaskDescription(String taskDescription) 
    {
        this.taskDescription = taskDescription;
    }

    /**
     * @return the developerDetails
     */
    public String getDeveloperDetails() 
    {
        return developerDetails;
    }

    /**
     * @param developerDetails the developerDetails to set
     */
    public void setDeveloperDetails(String developerDetails) 
    {
        this.developerDetails = developerDetails;
    }

    /**
     * @return the taskDuration
     */
    public int getTaskDuration() 
    {
        return taskDuration;
    }

    /**
     * @return the taskID
     */
    public String getTaskID() 
    {
        return taskID;
    }

    /**
     * @param taskID the taskID to set
     */
    public void setTaskID(String taskID) 
    {
        this.taskID = taskID;
    }

    /**
     * @return the taskStatus
     */
    public String getTaskStatus() 
    {
        return taskStatus;
    }

    /**
     * @param taskStatus the taskStatus to set
     */
    public void setTaskStatus(String taskStatus) 
    {
        this.taskStatus = taskStatus;
    }

}

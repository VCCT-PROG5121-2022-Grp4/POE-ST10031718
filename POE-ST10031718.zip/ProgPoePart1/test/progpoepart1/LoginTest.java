
package progpoepart1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ST10031718
 */
public class LoginTest 
{
    
    public LoginTest() 
    {}
    
    @BeforeAll
    public static void setUpClass() 
    {}
    
    @AfterAll
    public static void tearDownClass() 
    {}
    
    @BeforeEach
    public void setUp() 
    {}
    
    @AfterEach
    public void tearDown() 
    {}

    /**
     * Test of print method, of class Login.
     */
    @Test
    public void testPrint() {
        System.out.println("print");
        String sentence = "";
        Login.print(sentence);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName - kyl_1");
        String scanFor = "kyl_1";
        Login instance = new Login();
        boolean result = instance.checkUserName(scanFor);
        System.out.println("should be true :" + result);
        assertTrue(result);
        
        
        System.out.println("checkUsername - kyl_1");
        scanFor = "Kyl_1";
        result = instance.checkUserName(scanFor);
        System.out.println("should be false :" + result);
        assertFalse(result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkSPECIAL method, of class Login.
     */
    @Test
    public void testCheckSPECIAL() {
        System.out.println("checkSPECIAL");
        String scanFor = "";
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkSPECIAL(scanFor);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkDigit method, of class Login.
     */
    @Test
    public void testCheckDigit() {
        System.out.println("checkDigit");
        String scanFor = "";
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkDigit(scanFor);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkUpper method, of class Login.
     */
    @Test
    public void testCheckUpper() {
        System.out.println("checkUpper");
        String scanFor = "";
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkUpper(scanFor);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       //fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity - Ch&&secke99");
        String PswCmpl = "Ch&&secke99";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.checkPasswordComplexity(PswCmpl);
        assertEquals(expResult, result);
        
        System.out.println("checkPasswordComplexity - PswCmpl");
        PswCmpl = "password";
        expResult = false;
        result = instance.checkPasswordComplexity(PswCmpl);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class Login.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Login instance = new Login();
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setName method, of class Login.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String name = "";
        Login instance = new Login();
        instance.setName(name);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getSurname method, of class Login.
     */
    @Test
    public void testGetSurname() {
        System.out.println("getSurname");
        Login instance = new Login();
        String expResult = "";
        String result = instance.getSurname();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setSurname method, of class Login.
     */
    @Test
    public void testSetSurname() {
        System.out.println("setSurname");
        String surname = "";
        Login instance = new Login();
        instance.setSurname(surname);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getUsername method, of class Login.
     */
    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        Login instance = new Login();
        String expResult = "";
        String result = instance.getUsername();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUsername method, of class Login.
     */
    @Test
    public void testSetUsername() {
        System.out.println("setUsername");
        String username = "";
        Login instance = new Login();
        instance.setUsername(username);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPassword method, of class Login.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        Login instance = new Login();
        String expResult = "";
        String result = instance.getPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setPassword method, of class Login.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String password = "";
        Login instance = new Login();
        instance.setPassword(password);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getMAX_USERNAME method, of class Login.
     */
    @Test
    public void testGetMAX_USERNAME() {
        System.out.println("getMAX_USERNAME");
        Login instance = new Login();
        int expResult = 0;
        int result = instance.getMAX_USERNAME();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getMIN_PASSWORD method, of class Login.
     */
    @Test
    public void testGetMIN_PASSWORD() {
        System.out.println("getMIN_PASSWORD");
        Login instance = new Login();
        int expResult = 0;
        int result = instance.getMIN_PASSWORD();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getUNDERSCORE method, of class Login.
     */
    @Test
    public void testGetUNDERSCORE() {
        System.out.println("getUNDERSCORE");
        Login instance = new Login();
        String expResult = "";
        String result = instance.getUNDERSCORE();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getSPECIAL method, of class Login.
     */
    @Test
    public void testGetSPECIAL() {
        System.out.println("getSPECIAL");
        Login instance = new Login();
        String expResult = "";
        String result = instance.getSPECIAL();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package progpoepart1;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Tiaan
 */
public class TaskTest 
{
    
final int MAX_TASKS = 2;
    Task testTask = new Task();
    Task[] testArray = new Task[MAX_TASKS];    
    
 public void populateArray()
    {
         String taskID = "";
         String[] taskNames =  {"Login Feature,Add Task Feature"};
         String[] taskDescr =  {Create Login to authenticate users, Create Add Task feature to add task  users };
         String[] devDetails = {Robyn Harrison, Mike Smith};
         int[] taskDurations = {8,10}; 
         int[] taskStatus    = {0,1}; // 0 = To Do, 1 = Doing, 2 = Done
         
         for (int counter = 0; counter < taskNames.length; counter++)
         {
             taskID = testTask.createTaskID(taskNames[counter], 
                                   Task.getIncrementTaskNumber(), 
                                   devDetails[counter]);
             testTask.setValidTask(true);
             testTask.setTaskNumber();
             testTask.setTaskID(taskID);
             testTask.setTaskName(taskNames[counter]);
             testTask.setTaskDescription(taskDescr[counter]);
             testTask.setDeveloperDetails(devDetails[counter]);
             testTask.setTaskDuration(taskDurations[counter]);
             testTask.setTaskStatus(taskStatus[counter]);
             testArray[counter] = testTask;
         }
    }
    /**
     * Test of createTaskID method, of class Task.
     */
    @Test
    public void testCreateTaskID() 
    {
        System.out.println("createTaskID");
        String taskName = "Login Featur";
        int taskIncr = 0;
        String developer = "";
        Task instance = new Task();
        String expResult = "";
        String result = instance.createTaskID(taskName, taskIncr, developer);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    /**
     * Test of returnTotalHours method, of class Task.
     */
    @Test
    public void testReturnTotalHours() {
        System.out.println("returnTotalHours");
        Task instance = new Task();
        int expResult = 0;
        int result = instance.returnTotalHours();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        
       
    public void testCreateTaskIDinLoop()
    {
          String [] developerNames = new String[] {"Mike","Robyn"};
         
          String [] taskNames ={"login feature"," add task feature"};
         
          String [] testIDs = {"LF:0:IKE","AD:1:YN"};
         
          for (int i = 0; i < developerNames.length; i++)
          {
             String expected =  testIDs[i];
             String actual = testTask.createTaskID(taskNames[i], i, developerNames[i] );
             assertEquals(expected,actual);
          }
    }
}
